import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, TrendingUp, Truck, Package, BarChart3, Leaf, Info } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useCart } from '../contexts/CartContext';
import { Cart } from '../components/Cart';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const [showInfo, setShowInfo] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300"
    >
      <div 
        className="h-48 bg-cover bg-center"
        style={{ backgroundImage: `url(${product.image})` }}
      />
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <span className="text-sm text-green-600 font-medium">{product.category}</span>
          <button
            onClick={() => setShowInfo(!showInfo)}
            className="p-1 hover:bg-gray-100 rounded-full"
          >
            <Info className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.title}</h3>
        
        {showInfo && (
          <div className="mb-4 text-sm text-gray-600">
            <p className="mb-2">{product.description}</p>
            <ul className="list-disc list-inside space-y-1">
              {product.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        )}
        
        <div className="flex justify-between items-center mb-4">
          <p className="text-2xl font-bold text-gray-900">₹{product.price}</p>
          {product.originalPrice && (
            <p className="text-sm text-gray-500 line-through">₹{product.originalPrice}</p>
          )}
        </div>
        
        <button
          onClick={() => addToCart(product)}
          className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors duration-200 flex items-center justify-center space-x-2"
        >
          <ShoppingBag className="w-5 h-5" />
          <span>Add to Cart</span>
        </button>
      </div>
    </motion.div>
  );
};

const MarketStats = ({ icon: Icon, label, value }) => {
  return (
    <div className="flex items-center space-x-4 bg-white p-6 rounded-lg shadow-md">
      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
        <Icon className="w-6 h-6 text-green-600" />
      </div>
      <div>
        <p className="text-sm text-gray-600">{label}</p>
        <p className="text-xl font-bold text-gray-900">{value}</p>
      </div>
    </div>
  );
};

const MarketplacePage = () => {
  const { t } = useTranslation();

  const products = [
    {
      id: 1,
      title: "Organic Fertilizer",
      price: "1,200",
      originalPrice: "1,500",
      category: "Fertilizers",
      description: "Premium quality organic fertilizer suitable for all crop types.",
      features: [
        "100% organic ingredients",
        "Improves soil fertility",
        "Eco-friendly packaging",
        "6-month shelf life"
      ],
      image: "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 2,
      title: "Premium Seeds Pack",
      price: "450",
      category: "Seeds",
      description: "High-quality seeds with excellent germination rate.",
      features: [
        "High germination rate",
        "Disease resistant varieties",
        "Suitable for all seasons",
        "Lab tested quality"
      ],
      image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 3,
      title: "Farming Tools Set",
      price: "2,500",
      originalPrice: "3,000",
      category: "Equipment",
      description: "Complete set of essential farming tools.",
      features: [
        "Durable steel construction",
        "Ergonomic handles",
        "Rust-resistant coating",
        "Includes storage case"
      ],
      image: "https://images.unsplash.com/photo-1598512199776-e0aa7b3d88c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 4,
      title: "Pesticide Sprayer",
      price: "3,200",
      category: "Equipment",
      description: "Professional-grade pesticide sprayer with adjustable nozzle.",
      features: [
        "Large capacity tank",
        "Adjustable spray patterns",
        "Comfortable straps",
        "Battery-powered operation"
      ],
      image: "https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 5,
      title: "Bio Pesticides",
      price: "800",
      originalPrice: "1,000",
      category: "Pesticides",
      description: "Natural pest control solution safe for organic farming.",
      features: [
        "100% natural ingredients",
        "Safe for beneficial insects",
        "No harmful residues",
        "Long-lasting effectiveness"
      ],
      image: "https://images.unsplash.com/photo-1563074409-c1ea4485a0f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 6,
      title: "Soil Testing Kit",
      price: "1,500",
      category: "Equipment",
      description: "Professional soil testing kit for nutrient analysis.",
      features: [
        "Tests multiple parameters",
        "Easy to use",
        "Quick results",
        "Includes guide book"
      ],
      image: "https://images.unsplash.com/photo-1581093458791-9f3c3900b7e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    }
  ];

  const marketStats = [
    { icon: ShoppingBag, label: "Active Listings", value: "5,234" },
    { icon: Truck, label: "Vendors", value: "328" },
    { icon: Package, label: "Orders Today", value: "1,423" },
    { icon: BarChart3, label: "Market Growth", value: "+15.7%" }
  ];

  return (
    <div className="pt-16">
      <Cart />
      <div className="bg-green-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            {t('marketplace.exploreProducts.title')}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-green-100"
          >
            Your one-stop shop for all farming needs
          </motion.p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {marketStats.map((stat, index) => (
            <MarketStats key={index} {...stat} />
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MarketplacePage;