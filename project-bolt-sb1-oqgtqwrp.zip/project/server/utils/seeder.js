import mongoose from 'mongoose';
import dotenv from 'dotenv';
import colors from 'colors';
import User from '../models/User.js';
import Farmer from '../models/Farmer.js';
import Product from '../models/Product.js';
import Category from '../models/Category.js';
import { mockCategories, mockFarmers, mockProducts } from '../../src/data/mockData.js';

// Config
dotenv.config();

// Connect to DB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/natural-farming')
  .then(() => console.log('MongoDB connected successfully'.green.inverse))
  .catch(err => console.error(`MongoDB connection error: ${err}`.red.inverse));

// Import data
const importData = async () => {
  try {
    // Clear existing data
    await User.deleteMany();
    await Farmer.deleteMany();
    await Product.deleteMany();
    await Category.deleteMany();

    console.log('Data cleared...'.yellow);

    // Create admin user
    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@example.com',
      password: 'password123',
      role: 'admin'
    });

    console.log('Admin user created...'.green);

    // Create categories
    const categoryDocs = await Category.insertMany(
      mockCategories.map(cat => ({
        id: cat.id,
        name: cat.name,
        icon: cat.icon,
        description: `${cat.name} grown using natural farming methods`
      }))
    );

    console.log('Categories created...'.green);

    // Create farmer users and profiles
    const farmerUsers = [];
    for (const farmer of mockFarmers) {
      // Create user
      const user = await User.create({
        name: farmer.name,
        email: `${farmer.name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
        password: 'password123',
        role: 'farmer',
        profileImage: farmer.profileImage
      });

      farmerUsers.push(user);

      // Create farmer profile
      const farmerDoc = await Farmer.create({
        ...farmer,
        user: user._id,
        coordinates: {
          type: 'Point',
          coordinates: [73.8567, 18.5204] // Example coordinates for Pune
        }
      });

      console.log(`Farmer ${farmer.name} created...`.green);

      // Create products for this farmer
      const farmerProducts = mockProducts.filter(p => p.farmer.id === farmer.id);
      
      for (const product of farmerProducts) {
        const category = categoryDocs.find(c => c.id === product.categoryId);
        
        await Product.create({
          ...product,
          farmer: farmerDoc._id,
          category: category._id,
          harvestedDate: new Date(product.harvestedDate)
        });
      }

      console.log(`Products for ${farmer.name} created...`.green);
    }

    console.log('Data imported!'.green.inverse);
    process.exit();
  } catch (error) {
    console.error(`Error: ${error.message}`.red.inverse);
    process.exit(1);
  }
};

// Delete data
const destroyData = async () => {
  try {
    await User.deleteMany();
    await Farmer.deleteMany();
    await Product.deleteMany();
    await Category.deleteMany();

    console.log('Data destroyed!'.red.inverse);
    process.exit();
  } catch (error) {
    console.error(`Error: ${error.message}`.red.inverse);
    process.exit(1);
  }
};

// Run script based on command
if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}