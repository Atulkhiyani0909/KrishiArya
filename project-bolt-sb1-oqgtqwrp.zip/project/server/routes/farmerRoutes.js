import express from 'express';
import { 
  getFarmers, 
  getFarmerById, 
  createFarmerProfile, 
  updateFarmerProfile,
  createFarmerReview,
  getTopFarmers,
  verifyFarmer
} from '../controllers/farmerController.js';
import { protect, admin } from '../middleware/authMiddleware.js';
import upload from '../middleware/uploadMiddleware.js';

const router = express.Router();

router.route('/')
  .get(getFarmers)
  .post(protect, upload.array('farmImages', 5), createFarmerProfile);

router.get('/top', getTopFarmers);

router.route('/:id')
  .get(getFarmerById)
  .put(protect, upload.array('farmImages', 5), updateFarmerProfile);

router.route('/:id/reviews')
  .post(protect, createFarmerReview);

router.route('/:id/verify')
  .put(protect, admin, verifyFarmer);

export default router;