import express from 'express';
import { 
  getProducts, 
  getProductById, 
  createProduct, 
  updateProduct, 
  deleteProduct,
  getFeaturedProducts,
  getProductTraceability
} from '../controllers/productController.js';
import { protect, farmer } from '../middleware/authMiddleware.js';
import upload from '../middleware/uploadMiddleware.js';

const router = express.Router();

router.route('/')
  .get(getProducts)
  .post(protect, farmer, upload.single('image'), createProduct);

router.get('/featured', getFeaturedProducts);

router.route('/:id')
  .get(getProductById)
  .put(protect, farmer, updateProduct)
  .delete(protect, farmer, deleteProduct);

router.get('/:id/traceability', getProductTraceability);

export default router;