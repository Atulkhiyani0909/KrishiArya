import Farmer from '../models/Farmer.js';
import User from '../models/User.js';
import Product from '../models/Product.js';

// @desc    Get all farmers
// @route   GET /api/farmers
// @access  Public
export const getFarmers = async (req, res) => {
  try {
    const { 
      verified, 
      certification, 
      sort = 'rating',
      order = 'desc',
      limit = 10,
      page = 1,
      lat,
      lng,
      distance
    } = req.query;

    // Build query
    const query = {};
    
    if (verified !== undefined) {
      query.verified = verified === 'true';
    }
    
    if (certification) {
      query.certification = certification;
    }
    
    // Pagination
    const skip = (Number(page) - 1) * Number(limit);
    
    // Sort options
    const sortOptions = {};
    sortOptions[sort] = order === 'desc' ? -1 : 1;
    
    // Geospatial query if coordinates provided
    if (lat && lng && distance) {
      query.coordinates = {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [Number(lng), Number(lat)]
          },
          $maxDistance: Number(distance) * 1000 // Convert km to meters
        }
      };
    }
    
    // Execute query
    const farmers = await Farmer.find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(Number(limit));
    
    // Get total count for pagination
    const total = await Farmer.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: farmers.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      page: Number(page),
      farmers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get single farmer
// @route   GET /api/farmers/:id
// @access  Public
export const getFarmerById = async (req, res) => {
  try {
    const farmer = await Farmer.findById(req.params.id);
    
    if (!farmer) {
      return res.status(404).json({
        success: false,
        message: 'Farmer not found'
      });
    }
    
    // Get farmer's products
    const products = await Product.find({ 
      farmer: farmer._id,
      active: true
    });
    
    res.status(200).json({
      success: true,
      farmer,
      products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Create farmer profile
// @route   POST /api/farmers
// @access  Private
export const createFarmerProfile = async (req, res) => {
  try {
    // Check if user already has a farmer profile
    const existingFarmer = await Farmer.findOne({ user: req.user._id });
    if (existingFarmer) {
      return res.status(400).json({
        success: false,
        message: 'Farmer profile already exists for this user'
      });
    }
    
    // Update user role to farmer
    await User.findByIdAndUpdate(req.user._id, { role: 'farmer' });
    
    // Create farmer profile
    const farmer = new Farmer({
      user: req.user._id,
      ...req.body
    });
    
    const createdFarmer = await farmer.save();
    
    res.status(201).json({
      success: true,
      farmer: createdFarmer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Update farmer profile
// @route   PUT /api/farmers/:id
// @access  Private/Farmer
export const updateFarmerProfile = async (req, res) => {
  try {
    const farmer = await Farmer.findById(req.params.id);
    
    if (!farmer) {
      return res.status(404).json({
        success: false,
        message: 'Farmer not found'
      });
    }
    
    // Check if user is the owner of this farmer profile
    if (farmer.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this profile'
      });
    }
    
    // Update farmer profile
    Object.keys(req.body).forEach(key => {
      // Don't allow updating verified status or reviews directly
      if (key !== 'verified' && key !== 'reviews') {
        farmer[key] = req.body[key];
      }
    });
    
    const updatedFarmer = await farmer.save();
    
    res.status(200).json({
      success: true,
      farmer: updatedFarmer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Create farmer review
// @route   POST /api/farmers/:id/reviews
// @access  Private
export const createFarmerReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    
    const farmer = await Farmer.findById(req.params.id);
    
    if (!farmer) {
      return res.status(404).json({
        success: false,
        message: 'Farmer not found'
      });
    }
    
    // Check if user has already reviewed this farmer
    const alreadyReviewed = farmer.reviews.find(
      r => r.user.toString() === req.user._id.toString()
    );
    
    if (alreadyReviewed) {
      return res.status(400).json({
        success: false,
        message: 'You have already reviewed this farmer'
      });
    }
    
    // Get user info
    const user = await User.findById(req.user._id);
    
    // Create review
    const review = {
      user: req.user._id,
      userName: user.name,
      userImage: user.profileImage || '',
      rating: Number(rating),
      comment,
      date: new Date()
    };
    
    farmer.reviews.push(review);
    
    // Update farmer rating
    farmer.rating = farmer.reviews.reduce((acc, item) => item.rating + acc, 0) / farmer.reviews.length;
    farmer.reviewCount = farmer.reviews.length;
    
    await farmer.save();
    
    res.status(201).json({
      success: true,
      message: 'Review added',
      review
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get top rated farmers
// @route   GET /api/farmers/top
// @access  Public
export const getTopFarmers = async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 5;
    
    const farmers = await Farmer.find({ verified: true })
      .sort({ rating: -1 })
      .limit(limit);
    
    res.status(200).json({
      success: true,
      farmers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Verify farmer (admin only)
// @route   PUT /api/farmers/:id/verify
// @access  Private/Admin
export const verifyFarmer = async (req, res) => {
  try {
    const farmer = await Farmer.findById(req.params.id);
    
    if (!farmer) {
      return res.status(404).json({
        success: false,
        message: 'Farmer not found'
      });
    }
    
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to verify farmers'
      });
    }
    
    // Update verification status
    farmer.verified = true;
    
    // Update certification if provided
    if (req.body.certification) {
      farmer.certification = req.body.certification;
      farmer.certificationDate = new Date();
    }
    
    const updatedFarmer = await farmer.save();
    
    res.status(200).json({
      success: true,
      message: 'Farmer verified successfully',
      farmer: updatedFarmer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};