import Product from '../models/Product.js';
import Farmer from '../models/Farmer.js';
import Category from '../models/Category.js';
import mongoose from 'mongoose';

// @desc    Get all products
// @route   GET /api/products
// @access  Public
export const getProducts = async (req, res) => {
  try {
    const { 
      categoryId, 
      farmerId, 
      organic, 
      minPrice, 
      maxPrice, 
      sort = 'createdAt',
      order = 'desc',
      limit = 10,
      page = 1,
      lat,
      lng
    } = req.query;

    // Build query
    const query = {};
    
    if (categoryId) {
      query.categoryId = categoryId;
    }
    
    if (farmerId) {
      query.farmer = farmerId;
    }
    
    if (organic !== undefined) {
      query.organic = organic === 'true';
    }
    
    if (minPrice !== undefined || maxPrice !== undefined) {
      query.price = {};
      if (minPrice !== undefined) {
        query.price.$gte = Number(minPrice);
      }
      if (maxPrice !== undefined) {
        query.price.$lte = Number(maxPrice);
      }
    }
    
    // Only show active products
    query.active = true;
    
    // Pagination
    const skip = (Number(page) - 1) * Number(limit);
    
    // Sort options
    const sortOptions = {};
    sortOptions[sort] = order === 'desc' ? -1 : 1;
    
    // Execute query
    let products = await Product.find(query)
      .populate({
        path: 'farmer',
        select: 'name profileImage verified'
      })
      .populate('category', 'name icon')
      .sort(sortOptions)
      .skip(skip)
      .limit(Number(limit));
    
    // Calculate distance if coordinates provided
    if (lat && lng) {
      // Get all farmer locations
      const farmers = await Farmer.find({
        _id: { $in: products.map(p => p.farmer._id) }
      }).select('_id coordinates');
      
      const farmerMap = {};
      farmers.forEach(f => {
        farmerMap[f._id.toString()] = f.coordinates;
      });
      
      // Calculate distance for each product
      products = products.map(product => {
        const farmerCoords = farmerMap[product.farmer._id.toString()];
        if (farmerCoords && farmerCoords.coordinates) {
          // Calculate distance using Haversine formula
          const [farmerLng, farmerLat] = farmerCoords.coordinates;
          const distance = calculateDistance(
            Number(lat), 
            Number(lng), 
            farmerLat, 
            farmerLng
          );
          
          // Add distance to product
          const productObj = product.toObject();
          productObj.distance = Math.round(distance);
          return productObj;
        }
        return product;
      });
      
      // Sort by distance if requested
      if (sort === 'distance') {
        products.sort((a, b) => {
          return order === 'asc' 
            ? (a.distance || 0) - (b.distance || 0)
            : (b.distance || 0) - (a.distance || 0);
        });
      }
    }
    
    // Get total count for pagination
    const total = await Product.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: products.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      page: Number(page),
      products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get single product
// @route   GET /api/products/:id
// @access  Public
export const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate({
        path: 'farmer',
        select: 'name profileImage verified location'
      })
      .populate('category', 'name icon');
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // Calculate distance if coordinates provided
    if (req.query.lat && req.query.lng) {
      const farmer = await Farmer.findById(product.farmer._id).select('coordinates');
      
      if (farmer && farmer.coordinates && farmer.coordinates.coordinates) {
        const [farmerLng, farmerLat] = farmer.coordinates.coordinates;
        const distance = calculateDistance(
          Number(req.query.lat), 
          Number(req.query.lng), 
          farmerLat, 
          farmerLng
        );
        
        const productObj = product.toObject();
        productObj.distance = Math.round(distance);
        return res.status(200).json({
          success: true,
          product: productObj
        });
      }
    }
    
    res.status(200).json({
      success: true,
      product
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Create a product
// @route   POST /api/products
// @access  Private/Farmer
export const createProduct = async (req, res) => {
  try {
    // Check if user is a farmer
    const farmer = await Farmer.findOne({ user: req.user._id });
    if (!farmer) {
      return res.status(403).json({
        success: false,
        message: 'Only farmers can create products'
      });
    }
    
    // Check if category exists
    const category = await Category.findOne({ id: req.body.categoryId });
    if (!category) {
      return res.status(400).json({
        success: false,
        message: 'Invalid category'
      });
    }
    
    // Create product
    const product = new Product({
      ...req.body,
      farmer: farmer._id,
      category: category._id
    });
    
    const createdProduct = await product.save();
    
    res.status(201).json({
      success: true,
      product: createdProduct
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private/Farmer
export const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // Check if user is the farmer who created this product
    const farmer = await Farmer.findOne({ user: req.user._id });
    if (!farmer || farmer._id.toString() !== product.farmer.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this product'
      });
    }
    
    // Update category reference if categoryId is changed
    if (req.body.categoryId && req.body.categoryId !== product.categoryId) {
      const category = await Category.findOne({ id: req.body.categoryId });
      if (!category) {
        return res.status(400).json({
          success: false,
          message: 'Invalid category'
        });
      }
      req.body.category = category._id;
    }
    
    // Update product
    Object.keys(req.body).forEach(key => {
      product[key] = req.body[key];
    });
    
    const updatedProduct = await product.save();
    
    res.status(200).json({
      success: true,
      product: updatedProduct
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private/Farmer
export const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // Check if user is the farmer who created this product
    const farmer = await Farmer.findOne({ user: req.user._id });
    if (!farmer || farmer._id.toString() !== product.farmer.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this product'
      });
    }
    
    // Soft delete by setting active to false
    product.active = false;
    await product.save();
    
    res.status(200).json({
      success: true,
      message: 'Product removed'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get featured products
// @route   GET /api/products/featured
// @access  Public
export const getFeaturedProducts = async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 6;
    
    const products = await Product.find({ featured: true, active: true })
      .populate({
        path: 'farmer',
        select: 'name profileImage verified'
      })
      .limit(limit);
    
    res.status(200).json({
      success: true,
      count: products.length,
      products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get product traceability
// @route   GET /api/products/:id/traceability
// @access  Public
export const getProductTraceability = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate({
        path: 'farmer',
        select: 'name location certification farmingPractices'
      });
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    const traceabilityData = {
      product: {
        id: product._id,
        name: product.name,
        traceabilityCode: product.traceabilityCode,
        harvestedDate: product.harvestedDate,
        organic: product.organic
      },
      farmer: {
        name: product.farmer.name,
        location: product.farmer.location,
        certification: product.farmer.certification,
        farmingPractices: product.farmer.farmingPractices
      },
      farmingPractices: product.farmingPractices,
      verificationTimestamp: new Date()
    };
    
    res.status(200).json({
      success: true,
      traceability: traceabilityData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// Helper function to calculate distance using Haversine formula
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const distance = R * c; // Distance in km
  return distance;
};

const deg2rad = (deg) => {
  return deg * (Math.PI/180);
};