import Category from '../models/Category.js';
import Product from '../models/Product.js';

// @desc    Get all categories
// @route   GET /api/categories
// @access  Public
export const getCategories = async (req, res) => {
  try {
    const categories = await Category.find({ active: true });
    
    res.status(200).json({
      success: true,
      count: categories.length,
      categories
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Get single category
// @route   GET /api/categories/:id
// @access  Public
export const getCategoryById = async (req, res) => {
  try {
    const category = await Category.findOne({ id: req.params.id });
    
    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
    
    // Get products in this category
    const products = await Product.find({ 
      categoryId: category.id,
      active: true
    }).populate({
      path: 'farmer',
      select: 'name profileImage verified'
    });
    
    res.status(200).json({
      success: true,
      category,
      products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Create a category (admin only)
// @route   POST /api/categories
// @access  Private/Admin
export const createCategory = async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to create categories'
      });
    }
    
    // Check if category with this ID already exists
    const existingCategory = await Category.findOne({ id: req.body.id });
    if (existingCategory) {
      return res.status(400).json({
        success: false,
        message: 'Category with this ID already exists'
      });
    }
    
    // Create category
    const category = new Category({
      id: req.body.id,
      name: req.body.name,
      icon: req.body.icon,
      description: req.body.description || ''
    });
    
    const createdCategory = await category.save();
    
    res.status(201).json({
      success: true,
      category: createdCategory
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Update a category (admin only)
// @route   PUT /api/categories/:id
// @access  Private/Admin
export const updateCategory = async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update categories'
      });
    }
    
    const category = await Category.findOne({ id: req.params.id });
    
    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
    
    // Update category
    category.name = req.body.name || category.name;
    category.icon = req.body.icon || category.icon;
    category.description = req.body.description || category.description;
    
    const updatedCategory = await category.save();
    
    res.status(200).json({
      success: true,
      category: updatedCategory
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

// @desc    Delete a category (admin only)
// @route   DELETE /api/categories/:id
// @access  Private/Admin
export const deleteCategory = async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete categories'
      });
    }
    
    const category = await Category.findOne({ id: req.params.id });
    
    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
    
    // Check if there are products in this category
    const productCount = await Product.countDocuments({ categoryId: category.id });
    if (productCount > 0) {
      // Soft delete by setting active to false
      category.active = false;
      await category.save();
      
      return res.status(200).json({
        success: true,
        message: 'Category deactivated (products exist in this category)'
      });
    }
    
    // Hard delete if no products
    await category.deleteOne();
    
    res.status(200).json({
      success: true,
      message: 'Category removed'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
};

export { deleteCategory }