import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  userName: {
    type: String,
    required: true
  },
  userImage: {
    type: String
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  comment: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

const farmerSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Farmer name is required'],
    trim: true
  },
  profileImage: {
    type: String,
    default: ''
  },
  verified: {
    type: Boolean,
    default: false
  },
  location: {
    type: String,
    required: [true, 'Location is required']
  },
  coordinates: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: [0, 0]
    }
  },
  rating: {
    type: Number,
    default: 0
  },
  reviewCount: {
    type: Number,
    default: 0
  },
  joinedDate: {
    type: Date,
    default: Date.now
  },
  certification: {
    type: String,
    enum: ['Natural Farming Gold', 'Natural Farming Silver', 'Natural Farming Bronze', 'In Process', 'None'],
    default: 'None'
  },
  certificationDate: {
    type: Date
  },
  farmingType: {
    type: String,
    required: [true, 'Farming type is required']
  },
  customerCount: {
    type: Number,
    default: 0
  },
  bio: {
    type: String,
    required: [true, 'Bio is required']
  },
  farmingPractices: {
    type: String,
    required: [true, 'Farming practices description is required']
  },
  farmLocation: {
    type: String,
    required: [true, 'Farm location description is required']
  },
  farmImages: [String],
  reviews: [reviewSchema]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Index for geospatial queries
farmerSchema.index({ coordinates: '2dsphere' });

// Virtual for products
farmerSchema.virtual('products', {
  ref: 'Product',
  localField: '_id',
  foreignField: 'farmer'
});

// Update rating when reviews are modified
farmerSchema.pre('save', async function(next) {
  if (this.reviews.length > 0) {
    this.rating = this.reviews.reduce((acc, item) => item.rating + acc, 0) / this.reviews.length;
    this.reviewCount = this.reviews.length;
  }
  next();
});

const Farmer = mongoose.model('Farmer', farmerSchema);

export default Farmer;