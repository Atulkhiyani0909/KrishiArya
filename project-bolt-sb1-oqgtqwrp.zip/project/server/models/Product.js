import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  longDescription: {
    type: String,
    required: [true, 'Detailed product description is required']
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  unit: {
    type: String,
    required: [true, 'Unit of measurement is required'],
    trim: true
  },
  stock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: [0, 'Stock cannot be negative']
  },
  imageUrl: {
    type: String,
    required: [true, 'Product image is required']
  },
  additionalImages: [String],
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: [true, 'Category is required']
  },
  categoryId: {
    type: String,
    required: [true, 'Category ID is required']
  },
  organic: {
    type: Boolean,
    default: true
  },
  harvestedDate: {
    type: Date,
    required: [true, 'Harvest date is required']
  },
  farmingPractices: {
    type: String,
    required: [true, 'Farming practices description is required']
  },
  storageInstructions: {
    type: String,
    required: [true, 'Storage instructions are required']
  },
  farmer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Farmer',
    required: [true, 'Farmer is required']
  },
  featured: {
    type: Boolean,
    default: false
  },
  traceabilityCode: {
    type: String,
    unique: true
  },
  active: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Generate traceability code before saving
productSchema.pre('save', async function(next) {
  if (!this.traceabilityCode) {
    // Generate a unique traceability code
    const randomCode = Math.random().toString(36).substring(2, 10).toUpperCase();
    this.traceabilityCode = `NF-${randomCode}-${Date.now().toString().slice(-6)}`;
  }
  next();
});

// Virtual for calculating distance (to be populated at query time)
productSchema.virtual('distance').get(function() {
  return this._distance || 0;
});

const Product = mongoose.model('Product', productSchema);

export default Product;