import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema({
  id: {
    type: String,
    required: [true, 'Category ID is required'],
    unique: true,
    trim: true
  },
  name: {
    type: String,
    required: [true, 'Category name is required'],
    trim: true
  },
  icon: {
    type: String,
    required: [true, 'Category icon is required']
  },
  description: {
    type: String,
    default: ''
  },
  active: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Virtual for products in this category
categorySchema.virtual('products', {
  ref: 'Product',
  localField: 'id',
  foreignField: 'categoryId'
});

const Category = mongoose.model('Category', categorySchema);

export default Category;