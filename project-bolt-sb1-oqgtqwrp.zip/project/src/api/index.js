// Mock API functions to replace the backend
import { mockProducts, mockFarmers, mockCategories } from '../data/mockData';

// Products API
export const getProducts = async (params = {}) => {
  // Filter products based on params
  let filteredProducts = [...mockProducts];
  
  if (params.categoryId) {
    filteredProducts = filteredProducts.filter(p => p.categoryId === params.categoryId);
  }
  
  if (params.farmerId) {
    filteredProducts = filteredProducts.filter(p => p.farmer.id === params.farmerId);
  }
  
  return {
    success: true,
    products: filteredProducts,
    count: filteredProducts.length,
    total: filteredProducts.length,
    pages: 1,
    page: 1
  };
};

export const getProductById = async (id) => {
  const product = mockProducts.find(p => p.id === id);
  return {
    success: true,
    product
  };
};

export const getFeaturedProducts = async (limit = 6) => {
  const featuredProducts = mockProducts.slice(0, limit);
  return {
    success: true,
    products: featuredProducts,
    count: featuredProducts.length
  };
};

// Farmers API
export const getFarmers = async (params = {}) => {
  return {
    success: true,
    farmers: mockFarmers,
    count: mockFarmers.length,
    total: mockFarmers.length,
    pages: 1,
    page: 1
  };
};

export const getFarmerById = async (id) => {
  const farmer = mockFarmers.find(f => f.id === id);
  const products = mockProducts.filter(p => p.farmer.id === id);
  
  return {
    success: true,
    farmer,
    products
  };
};

export const getTopFarmers = async (limit = 5) => {
  const topFarmers = mockFarmers
    .filter(f => f.verified)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit);
    
  return {
    success: true,
    farmers: topFarmers
  };
};

// Categories API
export const getCategories = async () => {
  return {
    success: true,
    categories: mockCategories,
    count: mockCategories.length
  };
};

export const getCategoryById = async (id) => {
  const category = mockCategories.find(c => c.id === id);
  const products = mockProducts.filter(p => p.categoryId === id);
  
  return {
    success: true,
    category,
    products
  };
};