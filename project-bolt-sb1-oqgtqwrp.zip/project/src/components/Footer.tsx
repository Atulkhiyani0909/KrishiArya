import React from 'react';
import { Leaf, Instagram, Facebook, Twitter } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-green-800 text-white pt-10 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Leaf className="h-6 w-6" />
              <span className="text-xl font-bold">NaturalHarvest</span>
            </div>
            <p className="text-green-100 mb-4">
              Bridging natural farmers and conscious consumers through transparency and trust.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-green-200 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-green-200 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-green-200 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-green-100 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-green-100 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/farmers" className="text-green-100 hover:text-white transition-colors">Our Farmers</Link></li>
              <li><Link to="/certification" className="text-green-100 hover:text-white transition-colors">Certification</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/category/vegetables" className="text-green-100 hover:text-white transition-colors">Vegetables</Link></li>
              <li><Link to="/category/fruits" className="text-green-100 hover:text-white transition-colors">Fruits</Link></li>
              <li><Link to="/category/grains" className="text-green-100 hover:text-white transition-colors">Grains</Link></li>
              <li><Link to="/category/dairy" className="text-green-100 hover:text-white transition-colors">Dairy Products</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <address className="not-italic text-green-100">
              <p>123 Nature Way</p>
              <p>Green Valley, Earth</p>
              <p className="mt-2">Email: info@naturalharvest.com</p>
              <p>Phone: (123) 456-7890</p>
            </address>
          </div>
        </div>
        
        <div className="border-t border-green-700 mt-8 pt-6 text-center text-green-200">
          <p>&copy; {currentYear} NaturalHarvest. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;