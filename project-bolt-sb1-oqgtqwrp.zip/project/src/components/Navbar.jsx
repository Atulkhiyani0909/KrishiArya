import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Leaf, Search, ShoppingCart, User, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  
  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);
  
  // Add scroll event listener
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleSearch = (e) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
    // Implement search functionality
  };
  
  return (
    <nav className={`sticky top-0 z-40 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-md' : 'bg-white shadow-sm'
    }`}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Leaf className="h-7 w-7 text-green-700" />
              <span className="text-xl font-bold text-gray-800 hidden xs:block">NaturalHarvest</span>
            </Link>
            
            <div className="hidden md:flex ml-8 space-x-6">
              <Link to="/" className={`text-gray-600 hover:text-green-700 font-medium ${
                location.pathname === '/' ? 'text-green-700' : ''
              }`}>Home</Link>
              <Link to="/categories" className={`text-gray-600 hover:text-green-700 font-medium ${
                location.pathname === '/categories' ? 'text-green-700' : ''
              }`}>Categories</Link>
              <Link to="/farmers" className={`text-gray-600 hover:text-green-700 font-medium ${
                location.pathname === '/farmers' ? 'text-green-700' : ''
              }`}>Farmers</Link>
              <Link to="/about" className={`text-gray-600 hover:text-green-700 font-medium ${
                location.pathname === '/about' ? 'text-green-700' : ''
              }`}>About Us</Link>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                placeholder="Search for natural products..."
                className="w-64 py-2 pl-10 pr-4 text-gray-700 bg-gray-50 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </form>
            
            <Link to="/cart" className="relative text-gray-600 hover:text-green-700">
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-600 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            
            <Link to="/profile" className="text-gray-600 hover:text-green-700">
              <User className="h-6 w-6" />
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Link to="/cart" className="relative text-gray-600 hover:text-green-700 mr-4">
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-600 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-600 hover:text-green-700 focus:outline-none"
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-2 shadow-lg">
          <div className="container mx-auto px-4">
            <form onSubmit={handleSearch} className="relative mb-4">
              <input
                type="text"
                placeholder="Search for natural products..."
                className="w-full py-2 pl-10 pr-4 text-gray-700 bg-gray-50 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <button type="submit" className="absolute right-3 top-2 text-green-700">
                Search
              </button>
            </form>
            
            <div className="flex flex-col space-y-3">
              <Link 
                to="/" 
                className={`text-gray-600 hover:text-green-700 font-medium py-2 ${
                  location.pathname === '/' ? 'text-green-700' : ''
                }`}
              >
                Home
              </Link>
              <Link 
                to="/categories" 
                className={`text-gray-600 hover:text-green-700 font-medium py-2 ${
                  location.pathname === '/categories' ? 'text-green-700' : ''
                }`}
              >
                Categories
              </Link>
              <Link 
                to="/farmers" 
                className={`text-gray-600 hover:text-green-700 font-medium py-2 ${
                  location.pathname === '/farmers' ? 'text-green-700' : ''
                }`}
              >
                Farmers
              </Link>
              <Link 
                to="/about" 
                className={`text-gray-600 hover:text-green-700 font-medium py-2 ${
                  location.pathname === '/about' ? 'text-green-700' : ''
                }`}
              >
                About Us
              </Link>
              <Link 
                to="/profile" 
                className={`text-gray-600 hover:text-green-700 font-medium py-2 ${
                  location.pathname === '/profile' ? 'text-green-700' : ''
                }`}
              >
                My Profile
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;