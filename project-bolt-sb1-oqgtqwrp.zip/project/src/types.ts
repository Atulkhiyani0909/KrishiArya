export interface Farmer {
  id: string;
  name: string;
  profileImage: string;
  verified: boolean;
  location: string;
  rating: number;
  reviewCount: number;
  joinedDate: string;
  certification: string;
  certificationDate: string;
  farmingType: string;
  customerCount: number;
  bio: string;
  farmingPractices: string;
  farmLocation: string;
  farmImages?: string[];
  reviews?: {
    userName: string;
    userImage: string;
    rating: number;
    comment: string;
    date: string;
  }[];
}

export interface Product {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  price: number;
  unit: string;
  stock: number;
  imageUrl: string;
  additionalImages?: string[];
  categoryId: string;
  organic: boolean;
  distance: number;
  harvestedDate: string;
  farmingPractices: string;
  storageInstructions: string;
  farmer: {
    id: string;
    name: string;
    profileImage: string;
    verified: boolean;
  };
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}