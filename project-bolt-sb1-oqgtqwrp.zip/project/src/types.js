// This file now exports type definitions as JSDoc comments for better IDE support
// without requiring TypeScript

/**
 * @typedef {Object} Farmer
 * @property {string} id
 * @property {string} name
 * @property {string} profileImage
 * @property {boolean} verified
 * @property {string} location
 * @property {number} rating
 * @property {number} reviewCount
 * @property {string} joinedDate
 * @property {string} certification
 * @property {string} certificationDate
 * @property {string} farmingType
 * @property {number} customerCount
 * @property {string} bio
 * @property {string} farmingPractices
 * @property {string} farmLocation
 * @property {string[]} [farmImages]
 * @property {Array<{userName: string, userImage: string, rating: number, comment: string, date: string}>} [reviews]
 */

/**
 * @typedef {Object} Product
 * @property {string} id
 * @property {string} name
 * @property {string} description
 * @property {string} longDescription
 * @property {number} price
 * @property {string} unit
 * @property {number} stock
 * @property {string} imageUrl
 * @property {string[]} [additionalImages]
 * @property {string} categoryId
 * @property {boolean} organic
 * @property {number} distance
 * @property {string} harvestedDate
 * @property {string} farmingPractices
 * @property {string} storageInstructions
 * @property {{id: string, name: string, profileImage: string, verified: boolean}} farmer
 */

/**
 * @typedef {Object} Category
 * @property {string} id
 * @property {string} name
 * @property {string} icon
 */

export {};